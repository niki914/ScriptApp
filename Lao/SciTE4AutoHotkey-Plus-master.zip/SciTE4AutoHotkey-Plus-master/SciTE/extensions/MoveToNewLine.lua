function MoveToNewLine()
	-- https://www.scintilla.org/CommandValues.html
	editor:LineEnd()
	editor:NewLine()
end