.. ahk documentation master file, created by
   sphinx-quickstart on Sat Apr  4 07:27:28 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ahk Python wrapper documentation
================================

`GitHub`_

.. _GitHub: https://github.com/spyoungtech/ahk

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   quickstart
   README
   api/index
   extending




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
